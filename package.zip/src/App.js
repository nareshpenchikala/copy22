import './App.css';
import InstructorApp from './components/course/InstructorApp';



function App() {
  return (
    <div className="App">
    <InstructorApp/>
    </div>
  );
}

export default App;
